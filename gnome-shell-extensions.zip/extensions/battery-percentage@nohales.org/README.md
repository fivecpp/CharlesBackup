Battery Percentage Extension
----------------------------

This extension just show the battery power remainging percentage at the panel.
